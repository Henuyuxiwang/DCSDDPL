function [score] = f1_score(label, predict)
   M = confusionmat(label, predict);
   %以下两行为二分类时用[score, TPR, TNR]
   TPR = M(2,2) / (M(2,1) + M(2,2)); %SE: TP/(TP+FN)
   TNR = M(1,1) / (M(1,1) + M(1,2)); %SP: TN/(TN+FP)
   %转置，可以不转同时调换方向
   M = M';
   precision = diag(M)./(sum(M,2) + 0.0001);  %按列求和: TP/(TP+FP)
   recall = diag(M)./(sum(M,1)+0.0001)'; %按行求和: TP/(TP+FN)
   precision = mean(precision);
   recall = mean(recall);
   score = 2*precision*recall/(precision + recall);
   fprintf('精确率: %.4f\n', precision);
   fprintf('召回率: %.4f\n', recall);
   fprintf('f1_score: %.4f\n', score);
end
