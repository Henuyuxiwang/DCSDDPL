function [ D_Mat ] = UpdateD(A_Mat,  X_Mat, DataMat, D_Mat ,alpha,gamma)
% Update D by Eq. (12)

[ ClassNum] = size(DataMat,2); % �����

for i=1:ClassNum
    Xi       = X_Mat{i};
    Ai       =A_Mat{i};
    I_Mat    = eye(size(Ai,1));
    Yi       = DataMat{i};
   D_Mat{i}  =(alpha*Ai'+Yi*Xi')*inv(Xi*Xi'+alpha*(Ai*Ai')+ gamma*I_Mat);
      
   
end

