function [ DataMat, D_Mat,D,Dgnd, A_Mat,  X_Mat ] = Initilization2( Data , Label, DictSize, tau)
% In this intilization function, we do the following things:
% 1. Random initialization of dictioanry pair D and P for each class
% 2. Precompute the class-specific inverse matrix used in Eq. (10)  �����ڸ������ض������ֵ䣩
% 3. Compute matrix class-specific code matrix A by Eq. (8) 
%    with the random initilized D and P  
%
% The randn seeds are setted to make sure the results in our paper are
% reproduceable. The randn seed setting can be removed, our algorithm is 
% not sensitive to the initilization of D and P. In most cases, different 
% initilization will lead to the same recognition accuracy on a wide randge
% of testing databases.
%% %%%%%%%%%%%%%%%%%%%%%%
ClassNum = max(Label);
Dim      = size(Data,1);
I_Mat    = eye(Dim,Dim);

for i=1:ClassNum
    TempData      = Data(:,Label==i);
    DataMat{i}    = TempData;
    randn('seed',i);  % randn ����һ����������                      
    D_Mat{i}    = normcol_equal(randn(Dim, DictSize));
    randn('seed',2*i);
    A_Mat{i}      = normcol_equal(randn(Dim, DictSize))';
    Dgnd_Mat{i} =ones(DictSize,1) * i;
    TempDataC     = Data(:,Label~=i);
 
end
%% %%%%%%%%%%%%%%%%%%%%%%
D=horzcat(D_Mat{:});
Dgnd=vertcat( Dgnd_Mat{:});
X_Mat = UpdateX(  D_Mat, DataMat, A_Mat,  tau, DictSize  );

