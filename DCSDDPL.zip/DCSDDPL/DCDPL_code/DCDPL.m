function [ D_Mat , EncoderMat ] = DCDPL( Data, Label, options)
%   ѵ���׶�DCDPL
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DictSize       = options.numofatoms_perclass; 
gamma          = options.gamma;  
iterations     = options.iterations;
tau            = options.tau;          
lambda         = options.lambda; 
alpha          = options.alpha;
beta           = options.beta ;
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%��ʼ�� �������ֵ䡢�ۺ��ֵ䡢����ϵ������PDPL���Ƶķ�ʽ
[ DataMat, D_Mat,D,Dgnd, A_Mat,  X_Mat ] = Initilization2( Data , Label, DictSize, tau);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:iterations
	[ X_Mat ] = UpdateX(  D_Mat, DataMat, A_Mat,  tau, DictSize );
    [ A,A_Mat ]   = UpdateA(Data , Label,D_Mat,D,Dgnd,  X_Mat,  A_Mat, DataMat, tau,lambda,alpha,beta );
    [ D_Mat ] = UpdateD(A_Mat,  X_Mat, DataMat, D_Mat ,alpha,gamma);
     
end

% Reorganize the P matrix to make the classification fast
for i=1:size(A_Mat,2)
    EncoderMat((i-1)*DictSize+1:i*DictSize,:) = A_Mat{i};
end
