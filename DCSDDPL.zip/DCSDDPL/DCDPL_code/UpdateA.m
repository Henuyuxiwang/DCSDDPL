function [A, A_Mat ] = UpdateA( Data , Label,D_Mat,D,Dgnd,  X_Mat,  A_Mat, DataMat, tau,lambda,alpha,beta)
% Update Ai by Eq.
% (10)%AX+XB=C�������(��Di'*Di)*Ai+Ai*(��Yi*Yi'+��Ys*Ys'+��Ds*Ds')=��Xi'*Yi+��Di'
%��PDPL����
ClassNum = size(X_Mat,2);
for i=1:ClassNum
    Yi      = DataMat{i};
    Ys      = Data(:,Label~=i);
    Di      = D_Mat{i};
    Ds      = D(:,Dgnd~=i);
    Xi      = X_Mat{i};
    Am   = alpha*(Di'*Di);
    Bm   = tau*(Yi*Yi')+lambda*(Ys*Ys')+beta*(Ds*Ds');%+ 0.0001*eye(size(Ds*Ds')
    Cm =tau*(Xi*Yi')+alpha*Di';
    
   A_Mat{i}= sylvester(Am,Bm,Cm);  
end
A=vertcat( A_Mat{:});
